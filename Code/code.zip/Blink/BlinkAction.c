#include "BlinkAction.h"
#include <led.h>
#include <sys_module.h>




VS_VOID LED_ALL_OFF (VS_VOID)
{return;
}

VS_VOID ToggleGREENLED (VS_VOID)
{ sys_led(LED_GREEN_TOGGLE);
}


 VS_VOID ToggleREDLED (VS_VOID)
{ sys_led(LED_RED_TOGGLE);
}

VS_INT8 stop_timer (VS_UINT8 tid)
{ return sys_timer_stop(tid);
}

VS_INT8 try_timer (VS_UINT8 tid, VS_UINT32 interval, VS_UINT8 type)
{ return sys_timer_start (tid, interval, type);
}

VS_VOID sys_timer (VS_INT event, VS_UINT ticks)
{return;
}
