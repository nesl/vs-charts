/*
 * Id:        Blink.c
 *
 * Function:  VS System Source File.
 *
 * Generated: Fri Jul 20 14:14:49 2007
 *
 * Coder 5, 4, 0, 1283
 * 
 * This is an automatically generated file. It will be overwritten by the Coder. 
 * 
 * DO NOT EDIT THE FILE! 
 */


/*
 * Include SEM Library Header File.
 */
#include "SEMLibB.h"


#if (VS_CODER_GUID != 0X030ca9d91)
#error The generated file does not match the SEMTypes.h header file.
#endif


/*
 * Include VS System Header File.
 */
#include "Blink.h"


/*
 * Include VS System Data Header File.
 */
#include "BlinkData.h"


/*
 * SEM Library Data Declaration.
 */
SEMDATABlink SEMBlink;


/*
 * VS System Data Declaration and Initialization.
 *
 * VS System Informations:
 * - Rule data format number:  0
 */
VSDATABlink const Blink = 
{
  {
    0X000, 0X000, 0X001, 0X001
  },
  {
    0X012, 0X000, 0X000, 0X003, 0X000, 0X022, 0X001, 0X000, 
    0X001, 0X003, 0X003, 0X002, 0X021, 0X001, 0X001, 0X000, 
    0X000, 0X004, 0X012, 0X002, 0X002, 0X001, 0X003, 0X001, 
    0X001, 0X012, 0X002, 0X003, 0X001, 0X002, 0X001, 0X001
  },
  {
    0X000, 0X00C, 0X005, 0X012, 0X019
  },
  {
    0X000, 0X001, 0X002, 0X003, 0X005
  }
};
