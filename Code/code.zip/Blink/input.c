#define PROJECT "Blink"
//#include <sys_module.h>

#include "SEMLibB.h"

/*  The below include directives contains declarations for a visualSTATE 
project/system . To use a different visualSTATE project, 
just replace the includes. */

#include "BlinkAction.h" 
#include "BlinkData.h"
void HandleError (unsigned char cc)
{;
}
void main_sys_init()
{unsigned char cc;
/* Define action expression variable. */
	SEM_ACTION_EXPRESSION_TYPE actionExpressNo;
	
	/* Define and initialize. In this case the reset event is SE_RESET. */
	SEM_EVENT_TYPE eventNo = SE_RESET;
	
	/* Initialize the VS System. */
	SEM_Init();
	
	/* Initialize external variables if used */
	/*SEM_InitExternalVariables();*/
	
	/* Initialize internal variables if used */
	/*SEM_InitInternalVariables();*/
	


/***** To Reset The System *******/
		/* Get next event from queue */	  
	
			if ((cc = SEM_Deduct(eventNo)) != SES_OKAY)
				HandleError(cc);
			
			/* Get resulting action expressions and execute them. */   // Specify the functions to be executed as a result of processes
																	   // all definitions is ($SYSTEM)Actions.c which depend on the OS used the
																	   // The Ones that are not defined in the file their defintions should be deleted from it
			while ((cc = SEM_GetOutput(&actionExpressNo)) == SES_FOUND)
				SEM_Action(actionExpressNo);
			if (cc != SES_OKAY)
				HandleError(cc);
			
			/* Change the next state vector. */
			if ((cc = SEM_NextState()) != SES_OKAY)
				HandleError(cc);
	


}






void main_sys(SEM_EVENT_TYPE eventNo, void* param)
{unsigned char cc;
/* Define action expression variable. */
	SEM_ACTION_EXPRESSION_TYPE actionExpressNo;
	
	/* Define and initialize. In this case the reset event is SE_RESET. */
	
	
	
		/* Get next event from queue */	  
		
		// Since now event is known now it has to be switched to get the appropriate parameters along with which it has to be deduced and interface it with SOS
		  // To be written by the programmer	
			/* Deduct the event. */
			if(param==NULL)
            {  if((cc = SEM_Deduct(eventNo)) != SES_OKAY)
				HandleError(cc);
            }
          // else
           // if ((cc = SEM_Deduct(eventNo,param)) != SES_OKAY)
		//		HandleError(cc);
        
        	
			/* Get resulting action expressions and execute them. */   // Specify the functions to be executed as a result of processes
																	   // all definitions is ($SYSTEM)Actions.c which depend on the OS used the
																	   // The Ones that are not defined in the file their defintions should be deleted from it
			while ((cc = SEM_GetOutput(&actionExpressNo)) == SES_FOUND)
				SEM_Action(actionExpressNo);
			if (cc != SES_OKAY)
				HandleError(cc);
			
			/* Change the next state vector. */
			if ((cc = SEM_NextState()) != SES_OKAY)
				HandleError(cc);
		    
		
        
	
}

// The modules message handler will queue the according events for the visual state system .... To be written on the programmers logic

