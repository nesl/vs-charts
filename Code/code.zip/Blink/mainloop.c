/* *** include directives *** */

#include <stdio.h>
#include <stdlib.h>

#include "SEMLibB.h"


#include "BlinkAction.h"
#include "BlinkData.h"

SEM_EVENT_TYPE scanInputs()
{ int i;
               scanf("%d",&i);
               switch(i)
               { case 0 : return(Init);
                 case 1 : return(Final);
                 case 2 : return(TimeOut);
                 default: exit(0);
               }

}
     
  

void main_init()
{
  
  /* Initialize the VS System. */
  SEM_Init();
  unsigned char cc;
  
  /* Define action expression variable. */
  SEM_ACTION_EXPRESSION_TYPE actionExpressNo;

  /* Define and initialize. In this case the reset event is SE_RESET. */
  SEM_EVENT_TYPE eventNo = SE_RESET;


  /* Do forever */
       
  
      if ((cc = SEM_Deduct(eventNo)) != SES_OKAY)
        printf("Deduction Error\n");
      
      /* Get resulting action expressions and execute them. */
      while ((cc = SEM_GetOutput(&actionExpressNo)) == SES_FOUND)
        SEM_Action(actionExpressNo);
      if (cc != SES_OKAY)
        printf("Action error\n");
      
      /* Change the next state vector. */
      if ((cc = SEM_NextState()) != SES_OKAY)
        printf("Next State Error\n");
    
  
  
       
}
 

void main_sys(SEM_EVENT_TYPE eventNo, void *param=NULL)
{ unsigned char cc;
  
  /* Define action expression variable. */
  SEM_ACTION_EXPRESSION_TYPE actionExpressNo;

  /* Define and initialize. In this case the reset event is SE_RESET. */
  SEM_EVENT_TYPE eventNo = SE_RESET;


  /* Do forever */
       
  
      if ((cc = SEM_Deduct(eventNo)) != SES_OKAY)
        printf("Deduction Error\n");
      
      /* Get resulting action expressions and execute them. */
      while ((cc = SEM_GetOutput(&actionExpressNo)) == SES_FOUND)
        SEM_Action(actionExpressNo);
      if (cc != SES_OKAY)
        printf("Action error\n");
      
      /* Change the next state vector. */
      if ((cc = SEM_NextState()) != SES_OKAY)
        printf("Next State Error\n");
    
  
  
    
}

