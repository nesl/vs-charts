/****** INPUTS TO EVENTS ********/		


#include "ledsys_drivers.h" 

#include "MY_systemData.h"

void scanInputs2 (void)
{ int PIND;
  scanf("%d",&PIND);
  switch (PIND) 
  {
      case BTN1:  SEQ_AddEvent( eButton1 ); // Send eButton1 to the queue
                  break;                    

      case BTN2:  SEQ_AddEvent( eButton2 ); // Send eButton2 to the queue
                  break;

      case BTN3:  SEQ_AddEvent( eButton3 ); // Send eButton3 to the queue
                  break;
                  
      default:    exit(0);break;                    
  }
}
