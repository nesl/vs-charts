/*
 * Id:        Blink.h
 *
 * Function:  VS System Header File.
 *
 * Generated: Fri Jul 20 14:14:49 2007
 *
 * Coder 5, 4, 0, 1283
 * 
 * This is an automatically generated file. It will be overwritten by the Coder. 
 * 
 * DO NOT EDIT THE FILE! 
 */


#ifndef __BLINK_H
#define __BLINK_H


/*
 * Include SEM Defines Header File.
 */
#include "SEMBDef.h"


#if (VS_CODER_GUID != 0X030ca9d91)
#error The generated file does not match the SEMTypes.h header file.
#endif


#endif
